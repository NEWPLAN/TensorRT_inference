from tensorflow import NodeDef
# Compatibility with Python 3.X where basestring no longer exists.
try:
    basestring
except NameError:
    basestring = str

""" Node Creation Functions """
# Creates free standing nodes.
def create_node(name, op=None, **kwargs):
    '''
    Creates a free-standing TensorFlow NodeDef with the specified properties.

    Args:
        name (str): The name of the node.
        op (str): The node's operation.
        dtype (tensorflow.DType): TensorFlow dtype.
        shape (tuple(int)): Iterable container (usually a tuple) describing the shape of a tensor.
        inputs (list(tensorflow.NodeDef) or str): Iterable container (usually a tuple) of input nodes or input node names. Supports mixed-type lists.
        **kwargs (AttrName=Value): Any additional fields that should be present in the node. Currently supports int, float, bool, list(int), list(float) and str.

    Returns:
        tensorflow.NodeDef
    '''
    node = NodeDef()
    node.name = name
    node.op = op if op else name
    for key, val in kwargs.items():
        if key == "dtype":
            node.attr["dtype"].type = val.as_datatype_enum
        elif key == "shape":
            for val in val:
                node.attr[key].shape.dim.add(size=val)
        elif key == "inputs":
            # Accept either nodes or strings. This method accepts mixed lists too.
            for input_node in val:
                if isinstance(input_node, tf.NodeDef):
                    node.input.append(input_node.name)
                elif isinstance(input_node, basestring):
                    node.input.append(input_node)
                else:
                    raise TypeError("Input type unrecognized. Must be a tensorflow.NodeDef or a string.")
        elif isinstance(val, int):
            node.attr[key + "_u_int"].i = val
        elif isinstance(val, float):
            node.attr[key + "_u_float"].f = val
        elif isinstance(val, bool):
            node.attr[key + "_u_bool"].b = val
        elif isinstance(val, list):
            if any(isinstance(n, float) for n in val):
                # If any of the values in the list are floats, the whole list gets promoted to floats.
                node.attr[key + "_u_flist"].list.f.extend(val)
            elif all(isinstance(n, int) for n in val):
                # For int lists, all values have to be ints - no downcasting should happen.
                node.attr[key + "_u_ilist"].list.i.extend(val)
        elif isinstance(val, basestring):
            # Workaround for unicode strings.
            try:
                node.attr[key + "_u_str"].s = str.encode(val)
            except TypeError:
                node.attr[key + "_u_str"].s = bytes(val)
        else:
            raise TypeError("Type: " + str(type(val)) + " unrecognized.")
    # Return a node will all the correct attributes
    return node
